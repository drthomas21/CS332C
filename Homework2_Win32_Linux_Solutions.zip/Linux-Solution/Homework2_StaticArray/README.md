To compile in Linux:
g++ -std=c++11 main.cpp -o main
