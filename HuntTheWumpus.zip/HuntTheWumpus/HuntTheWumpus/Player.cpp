#include "Player.h"
#include <string>

namespace game {
	namespace pieces {
		Player::Player(int i, std::string n)
			: Piece(i, n) {

		}
		void Player::doAction(int id = 0) {
			
		}
	}
}