Hunt The Wumpus
===============
Console Environment:
- Assuming Charset: UTF-8

Compiling:
- Ubuntu 14.04: g++ -std=c++11 *.cpp -o ./compiled/HuntTheWumpus-ubuntu_14_04_amd64

File Permission:
- The application needs to be able to read and write a data file in the same folder it was executed in