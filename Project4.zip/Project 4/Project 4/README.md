if you are compiling project for linux, make sure that gcc and g++ is at least 4.9 or newer
