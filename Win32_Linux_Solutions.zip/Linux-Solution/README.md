Compiled For:
Ubuntu 15.04 (64-bits)
g++ (Ubuntu 4.8.4-2ubuntu1~14.04) 4.8.4

Note For (Homework1_DuelingDoofuses):
- make sure to use C++11 since we are using the property "nullptr"
